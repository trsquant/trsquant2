TRS QUANT website prototype
============================

Files:
- index.html : full responsive brand website, learning hub, course previews, bot roadmap, links and a future investment interest mockup.
- links.html : Linktree-style profile links page.

Run locally:
1. Keep both HTML files in the same folder.
2. Open index.html in a browser.
3. Open links.html to preview the Linktree-style page.

Publish:
Upload both files to the same static hosting project (for example GitHub Pages or Cloudflare Pages). The link page will work at /links.html after deployment.

Important:
- The site is a front-end prototype. It has no server, payment processing, user accounts, email capture, course delivery, or live investment functionality.
- The interest form deliberately does not submit or store data.
- No shares or investment are offered by this prototype. Before raising money or selling company ownership, get qualified securities/corporate legal advice and build a compliant process.
- Courses marked planned are outlines, not completed products.
