# TRS QUANT website

Static, mobile-responsive site with two pages:
- `index.html` — main website
- `links.html` — bio/link-tree page

## Publish with GitHub Pages
1. Create or open a GitHub repository for the site.
2. Upload both HTML files to the repository root (keep the filenames unchanged).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
5. After GitHub finishes deployment, the main site URL will be `https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/` and the link-tree URL will be `https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/links.html`.

## Before promoting
- The “Register interest” button currently opens an on-page mockup/modal only; it does not submit or store leads. Connect a real form/CRM before using it for lead collection.
- Learning/course previews are educational mockups; clearly mark planned material as not yet available.
- No investment is offered by the website. Get appropriate legal/compliance advice before any securities or ownership offering.
